﻿using System;
namespace Collection_Hierarchy.Contracts
{
	public interface IRemoveElement
	{
		string Remove();
	}
}

