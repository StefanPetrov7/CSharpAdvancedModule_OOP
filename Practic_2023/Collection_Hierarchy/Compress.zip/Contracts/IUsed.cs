﻿using System;
namespace Collection_Hierarchy.Contracts
{
	public interface IUsed
	{
		int Used();
	}
}

