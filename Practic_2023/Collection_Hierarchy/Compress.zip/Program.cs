﻿using Collection_Hierarchy.Core;
namespace Collection_Hierarchy;

class Program
{
    static void Main(string[] args)
    {
        Engine engine = new Engine();
        engine.RunCollectios();
    }
}

