﻿using Pizza_Calories.Core;

namespace Pizza_Calories;

public class StartUp
{
    static void Main(string[] args)
    {
        Engine engine = new Engine();
        engine.MakePizza();
    }
}

