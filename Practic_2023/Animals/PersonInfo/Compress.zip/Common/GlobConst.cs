﻿namespace PersonInfo.Common
{
	public static  class GlobConst
	{
		public const string END_PROGRAM = "End";
	}
}

