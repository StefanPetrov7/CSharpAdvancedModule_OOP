﻿using System.Text.RegularExpressions;

using PersonInfo.Core;

namespace PersonInfo;


public class StartUp
{
    static void Main(string[] args)
    {
        Engine engine = new Engine();
        engine.Run();
        
    }
}

