﻿namespace PersonInfo.Contracts
{
    public interface IBrowsing
    {
        string Browese(string site);
    }
}

