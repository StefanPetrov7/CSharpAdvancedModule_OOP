﻿namespace PersonInfo.Contracts
{
	public interface ICalling
	{
		 string Call(string phone);
	}
}

