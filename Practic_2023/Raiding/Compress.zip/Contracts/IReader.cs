﻿using System;
namespace Raiding.Contracts
{
	public interface IReader
	{
		string Read();
	}
}

