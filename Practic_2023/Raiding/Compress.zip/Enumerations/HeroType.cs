﻿using System;
namespace Raiding.Enumerations
{
	public enum HeroType
	{
		Paladin,
		Warrior,
		Druid,
		Rogue,
	}
}

