﻿using System;
namespace WildFarm.Contracts
{
	public interface IReader
	{
		string Read();
	}
}

