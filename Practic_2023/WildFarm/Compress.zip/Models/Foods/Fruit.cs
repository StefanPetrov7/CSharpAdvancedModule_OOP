﻿using System;
namespace WildFarm.Models.Foods
{
    public class Fruit : Food
    {
        public Fruit(int qty) : base(qty)
        { }
    }
}

