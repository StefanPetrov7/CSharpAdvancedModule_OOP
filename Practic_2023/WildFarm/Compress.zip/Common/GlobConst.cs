﻿using System;
namespace WildFarm.Common
{
    public static class GlobConst
    {
        public const string IVALID_FOOD = "{0} does not eat {1}!";
        public const string INVALID_ANIMAL = "Invalid animal input";
    }
}

