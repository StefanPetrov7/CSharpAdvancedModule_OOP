﻿using System;
namespace WildFarm.Enumeration
{
    public enum AnimalType
    {
        Hen,
        Owl,
        Mouse,
        Cat,
        Dog,
        Tiger,
    }
}

