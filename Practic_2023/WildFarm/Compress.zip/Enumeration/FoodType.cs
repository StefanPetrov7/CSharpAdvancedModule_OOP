﻿using System;
namespace WildFarm.Enumeration
{
	public enum FoodType
	{
		Meat,
		Vegetable,
		Fruit,
		Seeds,
	}
}

