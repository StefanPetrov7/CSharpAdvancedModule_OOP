﻿using System;
namespace Raiding.Common
{
    public static class GlobalConstants
    {
        public const string VICTORY = "Victory!";
        public const string DEFEAT = "Defeat...";
    }
}
