﻿using System;
namespace Raiding.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
