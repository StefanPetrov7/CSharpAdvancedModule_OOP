﻿using System;
namespace Raiding.Enumeration
{
    public enum HeroTypes
    {
        Druid,
        Paladin,
        Rogue,
        Warrior,
    }
}
